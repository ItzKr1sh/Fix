import Header from '../components/Header';
import Hero from '../components/Hero';
import Features from '../components/Features';
import HowItWorks from '../components/HowItWorks';
import Pricing from '../components/Pricing';
import LiveTicker from '../components/LiveTicker';
import StickyWidgets from '../components/StickyWidgets';
import Footer from '../components/Footer';
import ParticleBackground from '../components/ParticleBackground';

function Index() {
  return (
    <div className="min-h-screen bg-gray-900 text-white relative overflow-x-hidden">
      <ParticleBackground />
      <Header />
      <LiveTicker />
      <Hero />
      <Features />
      <HowItWorks />
      <Pricing />
      <Footer />
      <StickyWidgets />
    </div>
  );
}

export default Index;