const Pricing = () => {
  return (
    <section id="pricing" className="py-20 px-4 sm:px-6 lg:px-8 relative z-10">
      <div className="max-w-4xl mx-auto">
        {/* Section Header */}
        <div className="text-center mb-16">
          <h2 className="text-3xl sm:text-5xl font-bold mb-6">
            <span className="bg-gradient-to-r from-green-400 via-blue-400 to-pink-400 bg-clip-text text-transparent">
              Stealth Pricing
            </span>
          </h2>
          <p className="text-xl text-gray-300 max-w-2xl mx-auto">
            Simple, transparent pricing. No hidden fees, just pure stealth delivery value.
          </p>
        </div>

        {/* Pricing Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {/* Intro Offer */}
          <div className="relative group">
            {/* Limited Time Badge */}
            <div className="absolute -top-4 -right-4 z-20">
              <div className="bg-gradient-to-r from-pink-400 to-red-500 text-white px-4 py-2 rounded-full text-sm font-bold transform rotate-12 shadow-lg animate-pulse">
                🔥 LIMITED TIME
              </div>
            </div>

            <div className="bg-gray-800/50 backdrop-blur-md rounded-2xl p-8 border-2 border-green-400 hover:border-green-300 transition-all duration-300 transform hover:scale-105 hover:shadow-2xl hover:shadow-green-500/25 relative overflow-hidden">
              {/* Gradient Glow */}
              <div className="absolute inset-0 bg-gradient-to-r from-green-400/10 to-blue-400/10 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
              
              <div className="relative z-10">
                <div className="text-center mb-6">
                  <h3 className="text-2xl font-bold text-green-400 mb-2">Intro Stealth</h3>
                  <div className="flex items-center justify-center gap-2 mb-4">
                    <span className="text-4xl font-bold text-white">₹99</span>
                    <div className="text-gray-400">
                      <div className="line-through text-lg">₹150</div>
                      <div className="text-sm">per drop</div>
                    </div>
                  </div>
                  <div className="bg-green-400/20 text-green-300 px-4 py-2 rounded-full text-sm font-semibold">
                    34% OFF - New Users Only
                  </div>
                </div>

                <ul className="space-y-3 mb-8">
                  <li className="flex items-center gap-3">
                    <span className="w-5 h-5 bg-green-400 rounded-full flex items-center justify-center">
                      <svg className="w-3 h-3 text-white" fill="currentColor" viewBox="0 0 20 20">
                        <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                      </svg>
                    </span>
                    <span className="text-gray-300">Complete Ghost Mode</span>
                  </li>
                  <li className="flex items-center gap-3">
                    <span className="w-5 h-5 bg-green-400 rounded-full flex items-center justify-center">
                      <svg className="w-3 h-3 text-white" fill="currentColor" viewBox="0 0 20 20">
                        <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                      </svg>
                    </span>
                    <span className="text-gray-300">Scheduled Delivery</span>
                  </li>
                  <li className="flex items-center gap-3">
                    <span className="w-5 h-5 bg-green-400 rounded-full flex items-center justify-center">
                      <svg className="w-3 h-3 text-white" fill="currentColor" viewBox="0 0 20 20">
                        <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                      </svg>
                    </span>
                    <span className="text-gray-300">Rewards & Badges</span>
                  </li>
                  <li className="flex items-center gap-3">
                    <span className="w-5 h-5 bg-green-400 rounded-full flex items-center justify-center">
                      <svg className="w-3 h-3 text-white" fill="currentColor" viewBox="0 0 20 20">
                        <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                      </svg>
                    </span>
                    <span className="text-gray-300">24/7 Support</span>
                  </li>
                </ul>

                <button className="w-full bg-gradient-to-r from-green-400 to-blue-500 hover:from-green-500 hover:to-blue-600 text-white py-4 rounded-full font-bold text-lg transition-all duration-300 transform hover:scale-105 shadow-lg hover:shadow-xl">
                  🚀 Start Ghost Mode - ₹99
                </button>
              </div>
            </div>
          </div>

          {/* Standard Pricing */}
          <div className="relative group">
            <div className="bg-gray-800/50 backdrop-blur-md rounded-2xl p-8 border border-gray-700 hover:border-gray-600 transition-all duration-300 transform hover:scale-105 hover:shadow-2xl relative overflow-hidden">
              {/* Gradient Glow */}
              <div className="absolute inset-0 bg-gradient-to-r from-blue-400/10 to-pink-400/10 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
              
              <div className="relative z-10">
                <div className="text-center mb-6">
                  <h3 className="text-2xl font-bold text-blue-400 mb-2">Standard Stealth</h3>
                  <div className="flex items-center justify-center gap-2 mb-4">
                    <span className="text-4xl font-bold text-white">₹150</span>
                    <div className="text-gray-400">
                      <div className="text-sm">per drop</div>
                    </div>
                  </div>
                  <div className="bg-blue-400/20 text-blue-300 px-4 py-2 rounded-full text-sm font-semibold">
                    Regular Price
                  </div>
                </div>

                <ul className="space-y-3 mb-8">
                  <li className="flex items-center gap-3">
                    <span className="w-5 h-5 bg-blue-400 rounded-full flex items-center justify-center">
                      <svg className="w-3 h-3 text-white" fill="currentColor" viewBox="0 0 20 20">
                        <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                      </svg>
                    </span>
                    <span className="text-gray-300">Complete Ghost Mode</span>
                  </li>
                  <li className="flex items-center gap-3">
                    <span className="w-5 h-5 bg-blue-400 rounded-full flex items-center justify-center">
                      <svg className="w-3 h-3 text-white" fill="currentColor" viewBox="0 0 20 20">
                        <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                      </svg>
                    </span>
                    <span className="text-gray-300">Scheduled Delivery</span>
                  </li>
                  <li className="flex items-center gap-3">
                    <span className="w-5 h-5 bg-blue-400 rounded-full flex items-center justify-center">
                      <svg className="w-3 h-3 text-white" fill="currentColor" viewBox="0 0 20 20">
                        <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                      </svg>
                    </span>
                    <span className="text-gray-300">VIP Upgrade Available</span>
                  </li>
                  <li className="flex items-center gap-3">
                    <span className="w-5 h-5 bg-blue-400 rounded-full flex items-center justify-center">
                      <svg className="w-3 h-3 text-white" fill="currentColor" viewBox="0 0 20 20">
                        <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                      </svg>
                    </span>
                    <span className="text-gray-300">Priority Support</span>
                  </li>
                </ul>

                <button className="w-full bg-gradient-to-r from-blue-400 to-pink-500 hover:from-blue-500 hover:to-pink-600 text-white py-4 rounded-full font-bold text-lg transition-all duration-300 transform hover:scale-105 shadow-lg hover:shadow-xl">
                  💎 Standard Drop - ₹150
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* VIP Info */}
        <div className="mt-12 text-center">
          <div className="bg-gradient-to-r from-purple-400/10 to-pink-400/10 backdrop-blur-md rounded-2xl p-6 border border-purple-400/30">
            <h4 className="text-xl font-bold text-purple-400 mb-2">🏆 VIP Stealth Unlocked</h4>
            <p className="text-gray-300 mb-4">
              Complete 5 successful drops to unlock VIP status with masked couriers, premium packaging, and exclusive badges.
            </p>
            <div className="flex justify-center gap-4 text-sm text-gray-400">
              <span>🎭 Masked Couriers</span>
              <span>📦 Premium Packaging</span>
              <span>⚡ Priority Delivery</span>
              <span>🏅 Exclusive Badges</span>
            </div>
          </div>
        </div>

        {/* Payment Info */}
        <div className="mt-8 text-center">
          <div className="inline-flex items-center gap-2 bg-gray-800/50 backdrop-blur-md rounded-full px-6 py-3 border border-gray-700">
            <span className="text-2xl">💳</span>
            <span className="text-gray-300 text-sm font-medium">Secure UPI Payment • 9033407795@fam</span>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Pricing;