  const HowItWorks = () => {
  const steps = [
    {
      number: "01",
      title: "Ghost Order",
      description: "Tell us what you want delivered. Zero personal info required. Complete anonymity guaranteed.",
      icon: "👻",
      gradient: "from-green-400 to-green-600"
    },
    {
      number: "02", 
      title: "Stealth Pickup",
      description: "Our masked courier picks up your item. No questions asked. Your privacy is our priority.",
      icon: "🥷",
      gradient: "from-blue-400 to-blue-600"
    },
    {
      number: "03",
      title: "Invisible Drop",
      description: "Precise delivery to Mann PUC Center, Bhilad. Exact timing. Zero traces. Mission complete.",
      icon: "📍",
      gradient: "from-pink-400 to-pink-600"
    }
  ];

  return (
    <section id="how-it-works" className="py-20 px-4 sm:px-6 lg:px-8 relative z-10">
      <div className="max-w-6xl mx-auto">
        {/* Section Header */}
        <div className="text-center mb-16">
          <h2 className="text-3xl sm:text-5xl font-bold mb-6">
            <span className="bg-gradient-to-r from-green-400 via-blue-400 to-pink-400 bg-clip-text text-transparent">
              How It Works
            </span>
          </h2>
          <p className="text-xl text-gray-300 max-w-2xl mx-auto">
            Three simple steps to complete stealth. No traces, no questions, just results.
          </p>
        </div>

        {/* Steps */}
        <div className="relative">
          {/* Connection Line */}
          <div className="hidden lg:block absolute top-1/2 left-0 right-0 h-0.5 bg-gradient-to-r from-green-400 via-blue-400 to-pink-400 opacity-30 transform -translate-y-1/2"></div>
          
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 lg:gap-12">
            {steps.map((step, index) => (
              <div key={index} className="relative group">
                {/* Step Card */}
                <div className="bg-gray-800/50 backdrop-blur-md rounded-2xl p-8 border border-gray-700 hover:border-gray-600 transition-all duration-300 transform hover:scale-105 hover:shadow-2xl relative z-10">
                  {/* Gradient Glow */}
                  <div className={`absolute inset-0 bg-gradient-to-r ${step.gradient} opacity-0 group-hover:opacity-10 rounded-2xl transition-opacity duration-300`}></div>
                  
                  {/* Step Number */}
                  <div className="relative z-10">
                    <div className={`inline-flex items-center justify-center w-16 h-16 rounded-full bg-gradient-to-r ${step.gradient} text-white font-bold text-xl mb-6`}>
                      {step.number}
                    </div>
                    
                    {/* Icon */}
                    <div className="text-4xl mb-4">{step.icon}</div>
                    
                    {/* Content */}
                    <h3 className="text-2xl font-bold mb-4 text-white group-hover:text-transparent group-hover:bg-gradient-to-r group-hover:bg-clip-text group-hover:from-white group-hover:to-gray-300 transition-all duration-300">
                      {step.title}
                    </h3>
                    <p className="text-gray-400 group-hover:text-gray-300 transition-colors duration-300 leading-relaxed">
                      {step.description}
                    </p>
                  </div>
                </div>

                {/* Connection Arrow (Mobile) */}
                {index < steps.length - 1 && (
                  <div className="lg:hidden flex justify-center my-6">
                    <div className="w-0.5 h-8 bg-gradient-to-b from-gray-600 to-gray-700"></div>
                    <div className="absolute">
                      <svg className="w-4 h-4 text-gray-600 mt-6" fill="currentColor" viewBox="0 0 20 20">
                        <path fillRule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clipRule="evenodd" />
                      </svg>
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Bottom Stats */}
        <div className="mt-16 grid grid-cols-2 md:grid-cols-4 gap-6">
          <div className="text-center">
            <div className="text-2xl font-bold text-green-400 mb-2">&lt; 30min</div>
            <div className="text-sm text-gray-400">Average Delivery</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-blue-400 mb-2">100%</div>
            <div className="text-sm text-gray-400">Success Rate</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-pink-400 mb-2">0</div>
            <div className="text-sm text-gray-400">Data Stored</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-purple-400 mb-2">24/7</div>
            <div className="text-sm text-gray-400">Ghost Mode</div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HowItWorks;