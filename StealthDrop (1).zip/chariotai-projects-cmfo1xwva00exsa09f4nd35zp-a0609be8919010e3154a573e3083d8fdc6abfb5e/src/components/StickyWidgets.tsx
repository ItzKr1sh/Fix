import { useState, useEffect } from 'react';

const StickyWidgets = () => {
  const [activeOrders, setActiveOrders] = useState(12);
  const [ghostStreak, setGhostStreak] = useState(7);
  const [vipSlots, setVipSlots] = useState(3);

  useEffect(() => {
    // Simulate dynamic updates
    const interval = setInterval(() => {
      setActiveOrders(prev => Math.max(8, Math.min(25, prev + (Math.random() > 0.5 ? 1 : -1))));
      if (Math.random() > 0.8) {
        setGhostStreak(prev => prev + 1);
      }
      if (Math.random() > 0.9) {
        setVipSlots(prev => Math.max(0, Math.min(5, prev + (Math.random() > 0.5 ? 1 : -1))));
      }
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="fixed right-4 top-1/2 transform -translate-y-1/2 z-40 space-y-4 hidden lg:block">
      {/* Active Orders Widget */}
      <div className="bg-gray-800/80 backdrop-blur-md rounded-2xl p-4 border border-gray-700 shadow-2xl min-w-[200px]">
        <div className="flex items-center gap-3 mb-2">
          <div className="w-3 h-3 bg-green-400 rounded-full animate-pulse"></div>
          <span className="text-sm font-semibold text-gray-300">Live Orders</span>
        </div>
        <div className="text-2xl font-bold text-white mb-1">{activeOrders}</div>
        <div className="text-xs text-gray-400">Active ghost drops</div>
      </div>

      {/* Ghost Streak Widget */}
      <div className="bg-gray-800/80 backdrop-blur-md rounded-2xl p-4 border border-gray-700 shadow-2xl min-w-[200px]">
        <div className="flex items-center gap-3 mb-2">
          <span className="text-lg">👻</span>
          <span className="text-sm font-semibold text-gray-300">Ghost Streak</span>
        </div>
        <div className="text-2xl font-bold text-blue-400 mb-1">{ghostStreak} days</div>
        <div className="text-xs text-gray-400">Perfect stealth record</div>
      </div>

      {/* VIP Slots Widget */}
      <div className="bg-gray-800/80 backdrop-blur-md rounded-2xl p-4 border border-gray-700 shadow-2xl min-w-[200px]">
        <div className="flex items-center gap-3 mb-2">
          <span className="text-lg">💎</span>
          <span className="text-sm font-semibold text-gray-300">VIP Slots</span>
        </div>
        <div className="text-2xl font-bold text-pink-400 mb-1">{vipSlots} left</div>
        <div className="text-xs text-gray-400">Limited availability</div>
        {vipSlots <= 2 && (
          <div className="mt-2 text-xs bg-red-500/20 text-red-300 px-2 py-1 rounded-full text-center animate-pulse">
            Almost full!
          </div>
        )}
      </div>

      {/* Achievements Widget */}
      <div className="bg-gray-800/80 backdrop-blur-md rounded-2xl p-4 border border-gray-700 shadow-2xl min-w-[200px]">
        <div className="flex items-center gap-3 mb-2">
          <span className="text-lg">🏆</span>
          <span className="text-sm font-semibold text-gray-300">Achievements</span>
        </div>
        <div className="space-y-2">
          <div className="flex items-center gap-2">
            <span className="text-xs">🥷</span>
            <span className="text-xs text-gray-400">Stealth Master</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-xs">⚡</span>
            <span className="text-xs text-gray-400">Speed Demon</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-xs">🎯</span>
            <span className="text-xs text-gray-400">Precision Drop</span>
          </div>
        </div>
      </div>

      {/* Quick Order Button */}
      <button className="w-full bg-gradient-to-r from-green-400 to-blue-500 hover:from-green-500 hover:to-blue-600 text-white py-3 px-4 rounded-2xl font-bold text-sm transition-all duration-300 transform hover:scale-105 shadow-2xl">
        🚀 Quick Order
      </button>
    </div>
  );
};

export default StickyWidgets;