import { useEffect, useState } from 'react';

const LiveTicker = () => {
  const [currentUpdate, setCurrentUpdate] = useState(0);

  const updates = [
    "👀 Arjun just received his stealth delivery in Bhilad",
    "🔥 Priya unlocked VIP status with 5 ghost deliveries",
    "⚡ Rahul's order dropped at exact location - 0 seconds late",
    "🎯 Sneha earned 'Ghost Master' badge for perfect stealth",
    "💎 Karan upgraded to VIP - masked courier assigned",
    "🚀 Ananya's mystery package delivered in ghost mode",
    "⭐ Rohan completed 10-day delivery streak",
    "🎮 Ishita unlocked exclusive summer theme skin",
    "🔮 Vikram's order vanished into thin air (delivered!)",
    "💫 Kavya earned 'Stealth Legend' achievement"
  ];

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentUpdate((prev) => (prev + 1) % updates.length);
    }, 4000);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="fixed top-16 w-full z-40 bg-gradient-to-r from-green-400/10 via-blue-400/10 to-pink-400/10 backdrop-blur-sm border-b border-gray-700/50">
      <div className="overflow-hidden whitespace-nowrap">
        <div className="animate-pulse py-2 px-4">
          <span className="inline-flex items-center text-sm font-medium text-gray-200">
            <span className="w-2 h-2 bg-green-400 rounded-full mr-2 animate-pulse"></span>
            LIVE: {updates[currentUpdate]}
          </span>
        </div>
      </div>
    </div>
  );
};

export default LiveTicker;