const Features = () => {
  const features = [
    {
      icon: "👻",
      title: "Ghost Mode",
      description: "Complete anonymity. Zero personal info shared. Your identity stays hidden forever.",
      gradient: "from-green-400 to-green-600"
    },
    {
      icon: "⏰",
      title: "Scheduled Drops",
      description: "Set exact delivery time and location. Guaranteed precise drop when you want it.",
      gradient: "from-blue-400 to-blue-600"
    },
    {
      icon: "💎",
      title: "VIP Delivery",
      description: "Masked couriers, premium packaging, extra discretion for ultimate stealth experience.",
      gradient: "from-pink-400 to-pink-600"
    },
    {
      icon: "🏆",
      title: "Rewards & Badges",
      description: "Collect streak badges, unlock VIP tiers. Gamified experience with exclusive rewards.",
      gradient: "from-purple-400 to-purple-600"
    },
    {
      icon: "🔗",
      title: "Referral System",
      description: "Invite friends → unlock VIP privileges, discounts, and exclusive achievement badges.",
      gradient: "from-yellow-400 to-orange-500"
    },
    {
      icon: "📱",
      title: "PWA Experience",
      description: "Mobile-first, installable app. Push notifications and seamless app-like behavior.",
      gradient: "from-cyan-400 to-teal-500"
    }
  ];

  return (
    <section id="features" className="py-20 px-4 sm:px-6 lg:px-8 relative z-10">
      <div className="max-w-7xl mx-auto">
        {/* Section Header */}
        <div className="text-center mb-16">
          <h2 className="text-3xl sm:text-5xl font-bold mb-6">
            <span className="bg-gradient-to-r from-green-400 via-blue-400 to-pink-400 bg-clip-text text-transparent">
              Stealth Features
            </span>
          </h2>
          <p className="text-xl text-gray-300 max-w-2xl mx-auto">
            Built for Gen Z privacy. Every feature designed for maximum anonymity and cool factor.
          </p>
        </div>

        {/* Features Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <div
              key={index}
              className="group relative bg-gray-800/50 backdrop-blur-md rounded-2xl p-6 border border-gray-700 hover:border-gray-600 transition-all duration-300 transform hover:scale-105 hover:shadow-2xl"
            >
              {/* Gradient Glow Effect */}
              <div className={`absolute inset-0 bg-gradient-to-r ${feature.gradient} opacity-0 group-hover:opacity-10 rounded-2xl transition-opacity duration-300`}></div>
              
              {/* Content */}
              <div className="relative z-10">
                <div className="text-4xl mb-4">{feature.icon}</div>
                <h3 className="text-xl font-bold mb-3 text-white group-hover:text-transparent group-hover:bg-gradient-to-r group-hover:bg-clip-text group-hover:from-white group-hover:to-gray-300 transition-all duration-300">
                  {feature.title}
                </h3>
                <p className="text-gray-400 group-hover:text-gray-300 transition-colors duration-300">
                  {feature.description}
                </p>
              </div>

              {/* Hover Particles */}
              <div className="absolute top-4 right-4 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                <div className={`w-2 h-2 bg-gradient-to-r ${feature.gradient} rounded-full animate-pulse`}></div>
              </div>
            </div>
          ))}
        </div>

        {/* Bottom CTA */}
        <div className="text-center mt-16">
          <div className="inline-flex items-center gap-2 bg-gray-800/50 backdrop-blur-md rounded-full px-6 py-3 border border-gray-700">
            <span className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></span>
            <span className="text-gray-300 text-sm font-medium">All features included in every order</span>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Features;