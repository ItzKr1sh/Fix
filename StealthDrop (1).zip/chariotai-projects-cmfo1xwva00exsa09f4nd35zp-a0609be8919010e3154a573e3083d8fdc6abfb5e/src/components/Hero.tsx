import { useState } from 'react';

const Hero = () => {
  const [orderDetails, setOrderDetails] = useState('');
  const [showOrderForm, setShowOrderForm] = useState(false);

  const handleOrderNow = () => {
    setShowOrderForm(true);
  };

  const handleSubmitOrder = () => {
    if (orderDetails.trim()) {
      // Create UPI payment link
      const upiLink = `upi://pay?pa=9033407795@fam&pn=StealthDrop&am=99&cu=INR&tn=StealthDrop Order: ${encodeURIComponent(orderDetails)}`;
      window.location.href = upiLink;
    }
  };

  return (
    <section className="relative min-h-screen flex items-center justify-center pt-20 pb-16 px-4 sm:px-6 lg:px-8">
      <div className="max-w-4xl mx-auto text-center relative z-10">
        {/* Hero Title */}
        <div className="mb-8">
          <h1 className="text-4xl sm:text-6xl lg:text-7xl font-bold mb-6 leading-tight">
            <span className="bg-gradient-to-r from-green-400 via-blue-400 to-pink-400 bg-clip-text text-transparent animate-pulse">
              We Deliver.
            </span>
            <br />
            <span className="text-white">
              You Stay Hidden.
            </span>
          </h1>
          
          <div className="relative">
            <div className="absolute inset-0 bg-gradient-to-r from-green-400/20 via-blue-400/20 to-pink-400/20 blur-3xl"></div>
            <p className="relative text-xl sm:text-2xl text-gray-300 mb-8 max-w-2xl mx-auto">
              Anonymous delivery service for Gen Z. Complete privacy, zero traces, maximum stealth.
            </p>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-3 gap-4 mb-12 max-w-md mx-auto">
          <div className="text-center">
            <div className="text-2xl sm:text-3xl font-bold text-green-400">247+</div>
            <div className="text-sm text-gray-400">Ghost Drops</div>
          </div>
          <div className="text-center">
            <div className="text-2xl sm:text-3xl font-bold text-blue-400">100%</div>
            <div className="text-sm text-gray-400">Anonymous</div>
          </div>
          <div className="text-center">
            <div className="text-2xl sm:text-3xl font-bold text-pink-400">24/7</div>
            <div className="text-sm text-gray-400">Available</div>
          </div>
        </div>

        {/* CTA Buttons */}
        {!showOrderForm ? (
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-8">
            <button
              onClick={handleOrderNow}
              className="group relative bg-gradient-to-r from-green-400 to-blue-500 hover:from-green-500 hover:to-blue-600 text-white px-8 py-4 rounded-full font-bold text-lg transition-all duration-300 transform hover:scale-105 shadow-2xl hover:shadow-green-500/25"
            >
              <span className="relative z-10">🚀 Order Now - ₹99</span>
              <div className="absolute inset-0 bg-gradient-to-r from-green-600 to-blue-700 rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
            </button>
            
            <button className="text-gray-300 hover:text-white px-8 py-4 rounded-full border border-gray-600 hover:border-gray-400 transition-all duration-300 font-semibold">
              👻 Learn About Ghost Mode
            </button>
          </div>
        ) : (
          <div className="max-w-md mx-auto mb-8">
            <div className="bg-gray-800/50 backdrop-blur-md rounded-2xl p-6 border border-gray-700">
              <h3 className="text-xl font-bold mb-4 text-green-400">What do you want delivered?</h3>
              <textarea
                value={orderDetails}
                onChange={(e) => setOrderDetails(e.target.value)}
                placeholder="Describe what you want us to pick up and deliver..."
                className="w-full p-3 bg-gray-700 rounded-lg text-white placeholder-gray-400 border border-gray-600 focus:border-green-400 focus:outline-none resize-none"
                rows={4}
              />
              <div className="text-sm text-gray-400 mb-4 mt-2">
                📍 Delivery to: Mann PUC Center, Bhilad, Near NH48 Rokadiya Hanuman Temple, Gujarat 396105
              </div>
              <div className="flex gap-3">
                <button
                  onClick={handleSubmitOrder}
                  disabled={!orderDetails.trim()}
                  className="flex-1 bg-gradient-to-r from-green-400 to-blue-500 hover:from-green-500 hover:to-blue-600 disabled:from-gray-600 disabled:to-gray-700 text-white px-6 py-3 rounded-full font-bold transition-all duration-300 disabled:cursor-not-allowed"
                >
                  💳 Pay ₹99 via UPI
                </button>
                <button
                  onClick={() => setShowOrderForm(false)}
                  className="px-6 py-3 border border-gray-600 text-gray-300 rounded-full hover:border-gray-400 hover:text-white transition-all duration-300"
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Trust Indicators */}
        <div className="flex flex-wrap justify-center items-center gap-6 text-sm text-gray-400">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 bg-green-400 rounded-full"></span>
            Zero Personal Info Stored
          </div>
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 bg-blue-400 rounded-full"></span>
            End-to-End Privacy
          </div>
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 bg-pink-400 rounded-full"></span>
            Masked Couriers
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;